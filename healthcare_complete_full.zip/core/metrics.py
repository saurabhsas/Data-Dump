
def get_kpis(df):
    return {
        "Total Cost": f"${df['PAID'].sum():,.0f}",
        "Medical Cost": f"${df['MEDICAL_PAID'].sum():,.0f}",
        "Pharmacy Cost": f"${df['RX_PAID'].sum():,.0f}",
        "ED Visits": f"{int(df['EDVISITS'].sum()):,}",
        "IP Visits": f"{int(df['IPVISITS'].sum()):,}"
    }
