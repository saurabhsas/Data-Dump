
METRIC_MAP = {
    "MEDICAL_PAID": "Medical Cost",
    "RX_PAID": "Pharmacy Cost",
    "PAID": "Total Cost"
}

def rename_all(df):
    return df.rename(columns=METRIC_MAP)
