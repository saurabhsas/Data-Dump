
def load_matched_datasets(df, matched):

    df["MEMBERID"]=df["MEMBERID"].astype(str)

    g1_ids = matched["G1_MEMBERID"].astype(str)
    g2_ids = matched["G2_MEMBERID"].astype(str)

    g1 = df[df["MEMBERID"].isin(g1_ids)].copy()
    g2 = df[df["MEMBERID"].isin(g2_ids)].copy()

    g1["GROUP"]="Group1"
    g2["GROUP"]="Group2"

    return g1,g2
