
import pandas as pd

def load_data(path="data/final_monthly.csv"):
    df = pd.read_csv(path)
    df.columns = df.columns.str.upper()
    return df
