
import pandas as pd

def build_pre_post_dataset(df, matched):

    ids = set(matched["G1_MEMBERID"].astype(str)) | set(matched["G2_MEMBERID"].astype(str))

    df["MEMBERID"]=df["MEMBERID"].astype(str)

    pre = df.copy(); pre["COHORT"]="Pre"
    post = df[df["MEMBERID"].isin(ids)].copy(); post["COHORT"]="Post"

    return pd.concat([pre,post])
