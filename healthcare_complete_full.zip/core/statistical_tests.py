
from scipy.stats import ttest_ind

def run_tests(g1,g2):

    cols=["PAID","MEDICAL_PAID","RX_PAID"]

    res=[]
    for c in cols:
        t=ttest_ind(g1[c],g2[c],equal_var=False)
        res.append((c,t.pvalue))
    return res
