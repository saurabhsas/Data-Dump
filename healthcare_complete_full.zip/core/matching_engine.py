
import pandas as pd

def caliper_matching_sas(g1, g2, caliper=0.01):

    g1 = g1[["MEMBER_UCI","MATCH_SCORE","LOB","MEMBERID"]].drop_duplicates()
    g2 = g2[["MEMBER_UCI","MATCH_SCORE","LOB","MEMBERID"]].drop_duplicates()

    g1["MATCH_SCORE"] = pd.to_numeric(g1["MATCH_SCORE"], errors="coerce")
    g2["MATCH_SCORE"] = pd.to_numeric(g2["MATCH_SCORE"], errors="coerce")

    g1["k"]=1; g2["k"]=1
    pairs = g1.merge(g2,on="k",suffixes=("_G1","_G2")).drop("k",axis=1)

    pairs["diff"] = abs(pairs["MATCH_SCORE_G1"] - pairs["MATCH_SCORE_G2"])

    pairs = pairs[
        (pairs["diff"] < caliper) &
        (pairs["LOB_G1"] == pairs["LOB_G2"]) &
        (pairs["MEMBER_UCI_G1"] != pairs["MEMBER_UCI_G2"])
    ]

    pairs = pairs.sort_values(["MEMBER_UCI_G2","diff"])

    used1=set(); used2=set()
    out=[]

    for _,r in pairs.iterrows():
        if r["MEMBER_UCI_G1"] not in used1 and r["MEMBER_UCI_G2"] not in used2:
            out.append({
                "G1_MEMBER_UCI":r["MEMBER_UCI_G1"],
                "G2_MEMBER_UCI":r["MEMBER_UCI_G2"],
                "G1_MEMBERID":r["MEMBERID_G1"],
                "G2_MEMBERID":r["MEMBERID_G2"],
                "SCORE_DIFF":r["diff"]
            })
            used1.add(r["MEMBER_UCI_G1"])
            used2.add(r["MEMBER_UCI_G2"])

    return pd.DataFrame(out)
