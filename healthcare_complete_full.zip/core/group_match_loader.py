
import pandas as pd, os

def load_group_match_data(path="data"):
    g1 = pd.read_csv(os.path.join(path,"Group1.csv"), dtype=str)
    g2 = pd.read_csv(os.path.join(path,"Group2.csv"), dtype=str)
    m = pd.read_csv(os.path.join(path,"Member_match_score.csv"))

    m["RUN_YM"] = m["RUN_YM"].astype(int)
    m = m.sort_values(["MEMBER_UCI","RUN_YM"]).drop_duplicates("MEMBER_UCI", keep="last")

    g1 = g1.merge(m, on="MEMBER_UCI", how="left")
    g2 = g2.merge(m, on="MEMBER_UCI", how="left")

    return g1, g2
