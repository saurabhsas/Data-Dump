
def run_prompt(prompt, df):

    if "GROUP" in df.columns:
        if prompt=="Monthly Total Cost Trend":
            return df.groupby(["ELIGIBILITYYEARANDMONTH","GROUP"])["PAID"].sum().reset_index()

        if prompt=="Total Cost by Line of Business":
            return df.groupby(["LINEOFBUSINESS","GROUP"])["PAID"].sum().reset_index()

    return df
