
import streamlit as st
import pandas as pd

from core.data_loader import load_data
from core.group_match_loader import load_group_match_data
from core.matching_engine import caliper_matching_sas
from core.matched_data_loader import load_matched_datasets
from core.query_router import run_prompt
from core.metrics import get_kpis
from core.statistical_tests import run_tests
from core.pre_post_analysis import build_pre_post_dataset

from visualization.chart_router import build_chart

st.title("Advanced Healthcare Matching System")

df = load_data()

g1,g2 = load_group_match_data()
matched = caliper_matching_sas(g1,g2)

g1_data,g2_data = load_matched_datasets(df,matched)
combined = pd.concat([g1_data,g2_data])

st.subheader("KPIs")
k1=get_kpis(g1_data)
k2=get_kpis(g2_data)

for k in k1:
    st.write(k, k1[k], "vs", k2[k])

prompt = st.selectbox("Select",[
    "Monthly Total Cost Trend",
    "Total Cost by Line of Business"
])

res = run_prompt(prompt,combined)
fig = build_chart(res,prompt)
st.plotly_chart(fig)

st.subheader("T-Test")
for r in run_tests(g1_data,g2_data):
    st.write(r)

st.subheader("Pre vs Post")
pp = build_pre_post_dataset(df,matched)
st.write(pp.groupby("COHORT")["PAID"].mean())
