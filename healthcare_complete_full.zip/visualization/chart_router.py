
import plotly.express as px

def build_chart(df,prompt):

    if "GROUP" in df.columns:
        if "ELIGIBILITYYEARANDMONTH" in df.columns:
            return px.line(df,x="ELIGIBILITYYEARANDMONTH",y="PAID",color="GROUP")

    return px.bar(df)
